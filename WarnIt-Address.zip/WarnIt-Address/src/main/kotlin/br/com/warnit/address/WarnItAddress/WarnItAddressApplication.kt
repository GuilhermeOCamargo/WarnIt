package br.com.warnit.address.WarnItAddress

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class WarnItAddressApplication

fun main(args: Array<String>) {
	runApplication<WarnItAddressApplication>(*args)
}
